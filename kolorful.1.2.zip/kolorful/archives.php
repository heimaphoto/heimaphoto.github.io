<?php
/*
Template Name: Archives Index
*/
?>
<?php get_header(); ?>
		
		<div id="Main-Content"  class="KonaBody">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
			<div class="Post-Content">
				<h3 class="Post-Title">Archives by Month:</h3>
					<div class="Post-Data">
 					 <ul>
					    <?php wp_get_archives('type=monthly'); ?>
					  </ul>
					</div>  
				<h3 class="Post-Title">Archives by Categories:</h3>
					<div class="Post-Data">
					  <ul>
					     <?php wp_list_cats(); ?>
					  </ul>
					</div>
			</div>
<?php endwhile; ?>
			
		</div>
	
	
	
	
	
	
	
<?php else: ?>
<div class="Post-Content"><h3><?php _e('Sorry, no posts matched your criteria.'); ?></h3></div></div>
<?php endif; ?>
		<?php get_sidebar();?>
		<div class="Clearer"></div>
</div>
<?php get_footer();?>