
<!-- begin sidebar -->
<div class="Sidebar">
	<div class="Widget">
		<?php 
			/* Widgetized sidebar, if you have the plugin installed. */
			if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(2) ) : ?>
			<div class="widget-content">
				<h2><?php _e("Search") ;?></h2>
				<?php include (TEMPLATEPATH . '/search-form.php'); ?>
			</div>
			<div class="Clearer"></div>
			<div class="widget-content">
				<h2><?php _e("Latest Posts");?></h2>
				<ul>
				<?php wp_get_archives('type=postbypost&limit=10'); ?>
				</ul>	
			</div>
			<div class="Clearer"></div>
		<?php endif; ?>
	</div>
</div>
<div class="Sidebar">
	<div class="Widget">
		<?php 
			/* Widgetized sidebar, if you have the plugin installed. */
			if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(1) ) : ?>
			
			<div class="widget-content">
				<h2><?php _e("Archives") ;?></h2>
				<ul>
					<?php wp_get_archives('type=monthly'); ?>
				</ul>
			</div>
			<div class="Clearer"></div>
			<div class="widget-content">
				<h2><?php _e("Categories") ;?></h2>
				<ul><?php wp_list_cats('hierarchical=0'); ?></ul>
			</div>
			<div class="Clearer"></div>
		<?php endif; ?>
	</div>
</div>
<!-- end sidebar -->
