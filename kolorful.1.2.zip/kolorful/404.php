<?php get_header(); ?>
		
		<div id="Main-Content" class="KonaBody">
		
	
			

<div class="Post-Content"><h3>404 Not Found</h3></div>

		
	
	
	
	
	
	
	
		</div>
		<?php get_sidebar(); ?>
		<div class="Clearer"></div>
</div>
<?php get_footer() ;?>