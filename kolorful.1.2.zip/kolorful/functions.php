<?php
if ( function_exists('register_sidebar') ){
	register_sidebars(3,array(
        'before_widget' => '<div id="%1$s" class="widget-content">',
        'after_widget' => '</div><div class="Clearer"></div>',
        'before_title' => '<h2>',
        'after_title' => '</h2>',
    ));
}
?>
