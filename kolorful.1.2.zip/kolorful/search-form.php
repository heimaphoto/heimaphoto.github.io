					<form method="get" id="searchform" action="<?php bloginfo('home'); ?>/">
  						<table border="0">
    					<tr>
      						<td><input type="text" value="<?php the_search_query(); ?>" style="width:160px;" name="s" id="s" /></td>
    					</tr>
    					<tr>
      					<td><input name="submit" type="submit" id="searchsubmit" value="Search" /></td>
   						 </tr>
  						</table>
					</form>
