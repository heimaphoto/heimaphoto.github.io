<?php get_header(); ?>
		
		<div id="Main-Content"  class="KonaBody">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
		
	
			
			<div class="Post-Content" id="post-<?php the_ID() ;?>">
				<h3 class="Post-Title">
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="Permalink of <?php the_title(); ?>"><?php the_title();?></a>
				</h3>
				<div class="Post-Info">
					<?php 
						_e('Posted by'); ?>
					<?php
						the_author();
					?>
					<?php
						_e('on'); 
					?>
					<?php
						the_date();
					?>
					<?php _e(' , ') ;?>
					<?php
						comments_popup_link('No comment','1 Comment', '% Comments');
					?>
				</div>
				<div class="Post-Data">
				<?php
					the_excerpt();
				?>
				</div>
				<div class="Post-Meta">
					<?php
						_e('Filed under : ');
					?>
					<?php
						the_category(', ')
					?>
				</div>
			</div>
		
	
<?php endwhile; ?>
			<div class="Post_Navigation">
				<div class="Prev_Entries">
				<?php posts_nav_link(' &laquo; ', 'Previous Entries', '') ;?>
				</div>
				<div class="Next_Entries">
				<?php posts_nav_link('&raquo; ', '', 'Next Entries') ;?>
				</div>
				<div class="Clearer"></div>
			</div>
			<div class="Clearer">&nbsp;</div>
		</div>
	
	
	
	
	
	
	
<?php else: ?>
<div class="Post-Content"><h3><?php _e('Sorry, no posts matched your criteria.'); ?></h3></div></div>
<?php endif; ?>
		<?php get_sidebar() ;?>
		<div class="Clearer"></div>
</div>
<?php get_footer() ;?>