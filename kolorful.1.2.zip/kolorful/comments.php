<?php // Do not delete these lines
	if ('comments.php' == basename($_SERVER['SCRIPT_FILENAME']))
		die ('Please do not load this page directly. Thanks!');

	if (!empty($post->post_password)) { // if there's a password
		if ($_COOKIE['wp-postpass_' . COOKIEHASH] != $post->post_password) {  // and it doesn't match the cookie
			?>

			<p class="nocomments">This post is password protected. Enter the password to view comments.<p>

			<?php
			return;
		}
	}

	/* This variable is for alternating comment background */
	$AltComments = 'Commentors-Alt';
	$Comments_Count = 1;
?>

<!-- You can start editing here. -->

<?php if ($comments) : ?>
				<h3 id="comments"><?php comments_number('No Responses', 'One Response', '% Responses' );?> to &#8220;<?php the_title(); ?>&#8221;</h3>
				<div class="Comments-List">
						<?php foreach ($comments as $comment) : ?>
							<div class="<?php echo $AltComments ;?>" id="comment-<?php COMMENT_ID() ;?>">
								<div style="width:35px; float:right;"><?php if(function_exists('get_avatar')){ ?>
									<?php echo get_avatar( $comment, 32 ); ?>
								<?php }?>
								</div>
								<cite><?php echo $Comments_Count ;?>. <?php comment_author_link() ?></cite><br /> said on
									<?php if($comment->comment_approved=='0') :?>
									<em>Your comment is awaiting moderation.</em>
									<?php endif; ?>
									 
									<a href="#comment-<?php comment_ID() ?>" title="Comment Permanent Link"><?php comment_date('F jS, Y') ?> at <?php comment_time() ?></a> <?php edit_comment_link('e','',''); ?>
									<div class="Comments-Data">
										
										<?php comment_text(); ?>
									</div>
								 <div style="clear:both;">
								 </div>
							</div>
						<?php 
						if($AltComments=='Commentors-Alt')$AltComments='Commentors';
						else $AltComments='Commentors-Alt';
						?>
						<?php $Comments_Count++;?>
						<?php endforeach ;?>
				</div>
 <?php else : // this is displayed if there are no comments so far ?>
		
<?php endif; ?>


<?php if ('open' == $post->comment_status) : ?>

<h3 id="respond">Leave a Reply</h3>

<?php if ( get_option('comment_registration') && !$user_ID ) : ?>
<p>You must be <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?redirect_to=<?php the_permalink(); ?>">logged in</a> to post a comment.</p>
<?php else : ?>

<form action="<?php echo get_option('siteurl'); ?>/wp-comments-post.php" method="post" id="commentform">

<?php if ( $user_ID ) : ?>
		<div class="Comment-Form">
		<table>
<p>Logged in as <a href="<?php echo get_option('siteurl'); ?>/wp-admin/profile.php"><?php echo $user_identity; ?></a>. <a href="<?php echo get_option('siteurl'); ?>/wp-login.php?action=logout" title="Log out of this account">Logout &raquo;</a></p>

<?php else : ?>
		<div class="Comment-Form">
		<table>
		<tr>
		  <td width="100"><label for="author">Name :</label></td>
		  <td><input type="text" name="author" id="author" value="<?php echo $comment_author; ?>" size="30" tabindex="1" /> <small><?php if ($req) echo "(required)"; ?></small></td>
			
		</tr>
		<tr>
			<td><label for="email">Mail :</label></td>
			<td><input type="text" name="email" id="email" value="<?php echo $comment_author_email; ?>" size="30" tabindex="2" /> <small>(will not be published) <?php if ($req) echo "(required)"; ?></small></td>
			
		</tr>
		<tr>
			<td><label for="url">Website :</label></td>
			<td><input type="text" name="url" id="url" value="<?php echo $comment_author_url; ?>" size="30" tabindex="3" /> <small>(opitional)</small></td>
			
		</tr>

<?php endif; ?>

<tr><td><strong>XHTML:</strong> </td><td>You can use these tags: <small><?php echo allowed_tags(); ?></small></td></tr>

		<tr>
			<td>&nbsp;</td>
			<td><textarea name="comment" id="comment" cols="80" rows="8" tabindex="4"></textarea></td>
			
		</tr>
		<tr>
			<td><input type="hidden" name="comment_post_ID" value="<?php echo $id; ?>" /></td>
			<td><input name="submit" type="submit" id="submit" tabindex="5" value="Submit Comment" />			</td>
			
		</tr>
		</table>
		</div>
<?php do_action('comment_form', $post->ID); ?>

</form>

<?php endif; // If registration required and not logged in ?>

<?php endif; // if you delete this the sky will fall on your head ?>

