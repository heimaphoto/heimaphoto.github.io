Kolorful Wordpress Theme
####### Text Version ########
##You can also read in PDF format #
##Under same directory #######
######################
This theme is my very first theme for Wordpress since I started blogging in Wordpress. Reason why I create this theme is to learn CSS technique for myself and also wanted to know about Wordpress theme functions. This theme is never based on any Wordpress themes, which are previously created. This themed is well formed in XHTML and CSS.
Features
� Three Columns
� Page links show in Navigation
� Two Columns when seeing a single post (you can customize)
� Can get Printable version on each post (I�ve put extra print.css for printing, well work in both IE and Firefox. But I did not test for Safari yet)
� Different color for sidebar header
� Alternative color in comments
� Excerpt posts for Archive, Category and Search
� Archives.php (Page) for showing Month, Year and Category
Changing Main layout
If you want to shows main layout starts from top of the browser, check #Content in style.css
#Content {
width : 850px;
margin:20px auto 10px auto;
background:#ffffff;
border:1px solid #ddd;
}
change this one to 0px
margin: 0px auto 10px auto;
I wanna suggest you to change like this
#Content {
width : 850px;
margin:0px auto 10px auto;
background:#ffffff;
border-left:1px solid #ddd;
border-right:1px solid #ddd;
border-bottom:1px solid #ddd;
}
Putting Banner in Header
I�m sure you want to put banner in Header. I�ve put a sample banner image which is gradient background. If you want to add banner image. Search #Heading in style.css and add the blue line
#Heading {
padding-top : 10px;
padding-left : 10px;
padding-right : 10px;
padding-bottom : 20px;
text-align:left;
margin: 5px 5px 5px 5px;
font-family : "Lucida Sans Unicode", "Lucida Grande", "Helvetica", Verdana, Arial, Sans-Serif;
background:url(images/header-bg.jpg) no-repeat;
}
header-bg.jpg is located in images folder under my theme directory. You can change with your own banner image.
Adding new widgets in sidebar
If you want to add new widgets in sidebar, Search these tags
<div class="Sidebar">
<div class="Widget">
�.
�
Your widgets are here
This is a sample widget for sidebar. H2 is header for widget, class is used for coloring. Color names are located in style.css
<h2 class="light_yellow_green">Sites I go</h2>
<div class="widget-content">
<a href="http://www.google.com">Google</a>
<a href="http://en.wikipedia.org">Wikipedia</a>
</div>
<div class="Clearer"></div>
put this widget in Sidebar
<div class=�Sidebar�>
<div class=�Widget�>
<h2 class="light_yellow_green">Sites I go</h2>
<div class="widget-content">
<a href="http://www.google.com">Google</a>
<a href="http://en.wikipedia.org">Wikipedia</a>
</div>
<div class="Clearer"></div>
<h2 class=�gray�>Second widget</h2>
<div class="widget-content">
<a href="http://www.google.com">Google</a>
<a href="http://en.wikipedia.org">Wikipedia</a>
</div>
<div class="Clearer"></div>
�
�
�
</div>
</div>
(Note: there are two sidebars in index.php)
Available colors for header in sidebar :
� Gray (class name : gray)
� Orange (class name: orange)
� Light Yellow Green (class name: light_yellow_green)
� Khaki (class name: khaki)
� Light Blue Cool (class name: light_blue_cool)
Making Archives Page
Create a page in Wordpress
Give a name for Title �Archives�
(Don�t write any in page content)
Search �Page Template� in sidebar and Select �Archive Index�
Publish it. There you will see Archive page links in Navigation
Enjoy my Kolorful Worpress Theme !!!
If any questions or suggestion, please leave a comment at
http://www.myokyawhtun.com/2007/05/17/kolorful-wordpress-theme.html
Best wishes,
Myo Kyaw Htun
http://www.myokyawhtun.com