<?php get_header(); ?>
		
		<div id="Main-Content-Single" class="KonaBody">
<?php if (have_posts()) : while (have_posts()) : the_post(); ?>
	
			<div id="next_prev_post">
			<?php previous_post('&laquo; %','','yes');?> | <?php next_post('% &raquo;','','yes');?>
			</div>
			<div class="Post-Content" id="post-<?php the_ID() ;?>">
				<h3 class="Post-Title">
					<a href="<?php the_permalink(); ?>" rel="bookmark" title="Permalink of <?php the_title(); ?>"><?php the_title();?></a>
				</h3>
				<div class="Post-Info">
					<?php 
						_e('Posted by'); ?>
					<?php
						the_author();
					?>
					<?php
						_e('on'); 
					?>
					<?php
						the_date();
					?>
					<?php
						_e(' , ');
					?>
					<a href="#comments"><?php
						comments_number('No comment','1 Comment', '% Comments');
					?></a>
					
				</div>
				
					
				<div class="Post-Data">
				<?php
					the_content(__('(Read more...)'));
				?>
				<p><?php _e("Tags : "); the_tags('', ', ','');?></p>
				</div>
				
				<div class="Post-Meta">
					<?php
						_e('Filed under : ');
					?>
					<?php
						the_category(', ')
					?>
					<?php
						_e(' | ');
					?>
					<a href="<?php trackback_url(true); ?>">Trackback URI</a>
					<?php
						_e(' | ');
					?>
					<?php comments_rss_link('Comments RSS','Subscribe to Comments\' RSS for this post'); ?>						
				</div>
			</div>
		
	
<?php endwhile; ?>
			<div class="Comments">
				<?php comments_template(); ?>
			</div>
			<div>
				<?php posts_nav_link(' &#183; ', 'Next Entries', 'Previous Entries') ;?>
			</div>
			<div class="Clearer">&nbsp;</div>
		</div>
	
	
	
	
	
	
	
<?php else: ?>
<div class="Post-Content"><h3><?php _e('Sorry, no posts matched your criteria.'); ?></h3></div></div>
<?php endif; ?>
		<!-- If you want to use two sidebars in single post. Please uncomment this line and remove
		<div class="Sidebar">
		 ....
		 
		</div> 
		<?php //get_sidebar(); ?>
		-->
		<div class="Sidebar">
			<div class="Widget">
				<?php 
					/* Widgetized sidebar, if you have the plugin installed. */
					if ( !function_exists('dynamic_sidebar') || !dynamic_sidebar(3) ) : ?>
						<div class="widget-content">
						<h2><?php _e("Search") ;?></h2>
						<?php include (TEMPLATEPATH . '/search-form.php'); ?>
						</div>
						<div class="Clearer"></div>
						<div class="widget-content">
						<h2><?php _e("Latest Posts");?></h2>
							<ul>
								<?php wp_get_archives('type=postbypost&limit=10'); ?>
							</ul>	
						</div>
						<div class="Clearer"></div>
						<div class="widget-content">
						<h2><?php _e("Archives") ;?></h2>
							<ul>
								<?php wp_get_archives('type=monthly'); ?>
							</ul>
						</div>
						<div class="Clearer"></div>
				<?php endif; ?>
			</div>
		</div>
		<div class="Clearer"></div>
</div>
<?php get_footer();?>