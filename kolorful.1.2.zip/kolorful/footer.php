		<div class="Clearer"></div>
				<!-- This will show when print -->
				<span id="printcopy">&copy; <?php bloginfo('title');?></span>
				
				<!-- Copyright -->
				<div id="Footer">
					<a href="http://validator.w3.org/check?uri=<?php bloginfo('url') ;?>">XHTML</a> , <a href="http://jigsaw.w3.org/css-validator/validator?uri=<?php bloginfo('url') ;?>">CSS</a> | 
				Powered by <a href="http://www.wordpress.org">Wordpress</a> | <a href="http://www.myokyawhtun.com/themes-templates/kolorful-wordpress-theme.html/">Theme</a> by <a href="http://www.myokyawhtun.com">Myo Kyaw Htun</a>
				</div>
</body>
</html>
